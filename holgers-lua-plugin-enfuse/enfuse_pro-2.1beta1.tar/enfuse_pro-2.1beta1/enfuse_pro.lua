--[[
  Enfuse professional for darktable 

  copyright (c) 2017  Holger Klemm
  
  darktable is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.
  
  darktable is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with darktable.  If not, see <http://www.gnu.org/licenses/>.
]]

--[[
Version 2.1 BETA 1 for darktable 2.2.X
  
   
ADDITIONAL SOFTWARE NEEDED FOR THIS SCRIPT
* align_image_stack (part of hugin)
* enfuse
* exivtool

USAGE
* require this file from your main luarc config file.

This plugin will add the new export modul "fusion to HDR or DFF image".
]]

local dt = require "darktable"
local gettext = dt.gettext

-- works only with darktable API version 4.0.0
dt.configuration.check_version(...,{4,0,0})

-- Tell gettext where to find the .mo file translating messages for a particular domain
gettext.bindtextdomain("enfuse_pro",dt.configuration.config_dir.."/lua/")

local function _(msgid)
    return gettext.dgettext("enfuse_pro", msgid)
end


-- command variables
-- align
cmd_align_radial_distortion=""
cmd_align_optimize_field=""            
cmd_align_optimize_center=""          
cmd_align_auto_crop=""  
cmd_align_distortion=""
cmd_align_grid_size=""
cmd_align_control_points=""  
cmd_align_control_points_remove=""
cmd_align_correlation=""   
cmd_align_use_gpu=""
-- enfuse
cmd_enfuse_exposure_weight=""                
cmd_enfuse_saturation_weight=""                
cmd_enfuse_contrast_weight=""
cmd_enfuse_exposure_optimum_weight="" 
cmd_enfuse_exposure_width_weight=""
cmd_enfuse_hard_masks=""
cmd_enfuse_save_masks=""
cmd_enfuse_contrast_window_size=""
cmd_enfuse_contrast_edge_scale=""
cmd_enfuse_contrast_min_curvature=""

cmd_enfuse_color_depth=""
cmd_enfuse_compression=""

first_imagefile=""
last_imagefile=""
cmd_tmp_path=""
cmd_output_path=""
cmd_output_image="" 
homepath=os.getenv("HOME")
-- exiv
cmd_exiv_copy_exiv=""
-- output
cmd_suffix_output_format=""
-- commands
alignStartCommand=""
enfuseStartCommand=""
exixStartCommand=""




-- initialize combobox and checkbox value for default
if dt.preferences.read("enfuse_pro",  "selected_fusion", "integer") == 0 then
    -- align defaults
   dt.preferences.write("enfuse_pro", "selected_fusion", "integer", 1)           --Typ HDR
   dt.preferences.write("enfuse_pro", "checked_radial_distortion", "bool", false)      
   dt.preferences.write("enfuse_pro", "checked_optimize_field", "bool", false) 
   dt.preferences.write("enfuse_pro", "checked_optimize_image_center", "bool", true) 
   dt.preferences.write("enfuse_pro", "checked_auto_crop", "bool", true) 
   dt.preferences.write("enfuse_pro", "checked_distortion", "bool", true) 
   dt.preferences.write("enfuse_pro", "selected_grid_size", "integer", 5)
   dt.preferences.write("enfuse_pro", "selected_control_points", "integer", 8)
   dt.preferences.write("enfuse_pro", "selected_control_points_remove", "integer", 3)
   dt.preferences.write("enfuse_pro", "selected_correlation", "integer", 9)
   -- enfuse defaults
   dt.preferences.write("enfuse_pro", "selected_fusion_type", "integer", 1)
   
   dt.preferences.write("enfuse_pro", "checked_hard_masks", "bool", false) 
   dt.preferences.write("enfuse_pro", "checked_save_masks", "bool", false) 
 --  dt.preferences.write("enfuse_pro", "checked_copy_exiv", "bool", true) 
   dt.preferences.write("enfuse_pro", "selected_contrast_window_size", "integer", 5)
   dt.preferences.write("enfuse_pro", "selected_contrast_edge_scale", "integer", 1)
   dt.preferences.write("enfuse_pro", "selected_contrast_min_curvature", "integer", 1) 
   dt.preferences.write("enfuse_pro", "set_exposure_weight", "float", 1.0)
   dt.preferences.write("enfuse_pro", "set_saturation_weight", "float", 0.5)
   dt.preferences.write("enfuse_pro", "set_contrast_weight", "float", 0.0)
   dt.preferences.write("enfuse_pro", "set_exposure_optimum_weight", "float", 0.5)
   dt.preferences.write("enfuse_pro", "set_exposure_width_weight", "float",0.2)
   
   -- preset HDR 1
   dt.preferences.write("enfuse_pro", "checked_hdr1_hard_masks", "bool", false) 
   dt.preferences.write("enfuse_pro", "checked_hdr1_save_masks", "bool", false) 
 --  dt.preferences.write("enfuse_pro", "checked_hdr1_copy_exiv", "bool", true) 
   dt.preferences.write("enfuse_pro", "selected_hdr1_contrast_window_size", "integer", 5)
   dt.preferences.write("enfuse_pro", "selected_hdr1_contrast_edge_scale", "integer", 1)
   dt.preferences.write("enfuse_pro", "selected_hdr1_contrast_min_curvature", "integer", 1) 
   dt.preferences.write("enfuse_pro", "set_hdr1_exposure_weight", "float", 1.0)
   dt.preferences.write("enfuse_pro", "set_hdr1_saturation_weight", "float", 0.5)
   dt.preferences.write("enfuse_pro", "set_hdr1_contrast_weight", "float", 0.0)
   dt.preferences.write("enfuse_pro", "set_hdr1_exposure_optimum_weight", "float", 0.5)
   dt.preferences.write("enfuse_pro", "set_hdr1_exposure_width_weight", "float",0.2)
   
   -- preset HDR 2
   dt.preferences.write("enfuse_pro", "checked_hdr2_hard_masks", "bool", false) 
   dt.preferences.write("enfuse_pro", "checked_hdr2_save_masks", "bool", false) 
 --  dt.preferences.write("enfuse_pro", "checked_hdr2_copy_exiv", "bool", true) 
   dt.preferences.write("enfuse_pro", "selected_hdr2_contrast_window_size", "integer", 5)
   dt.preferences.write("enfuse_pro", "selected_hdr2_contrast_edge_scale", "integer", 1)
   dt.preferences.write("enfuse_pro", "selected_hdr2_contrast_min_curvature", "integer", 1) 
   dt.preferences.write("enfuse_pro", "set_hdr2_exposure_weight", "float", 1.0)
   dt.preferences.write("enfuse_pro", "set_hdr2_saturation_weight", "float", 0.5)
   dt.preferences.write("enfuse_pro", "set_hdr2_contrast_weight", "float", 0.0)
   dt.preferences.write("enfuse_pro", "set_hdr2_exposure_optimum_weight", "float", 0.5)
   dt.preferences.write("enfuse_pro", "set_hdr2_exposure_width_weight", "float",0.2)
   
   -- preset HDR 3
   dt.preferences.write("enfuse_pro", "checked_hdr3_hard_masks", "bool", false) 
   dt.preferences.write("enfuse_pro", "checked_hdr3_save_masks", "bool", false) 
--   dt.preferences.write("enfuse_pro", "checked_hdr3_copy_exiv", "bool", true) 
   dt.preferences.write("enfuse_pro", "selected_hdr3_contrast_window_size", "integer", 5)
   dt.preferences.write("enfuse_pro", "selected_hdr3_contrast_edge_scale", "integer", 1)
   dt.preferences.write("enfuse_pro", "selected_hdr3_contrast_min_curvature", "integer", 1)  
   dt.preferences.write("enfuse_pro", "set_hdr3_exposure_weight", "float", 1.0)
   dt.preferences.write("enfuse_pro", "set_hdr3_saturation_weight", "float", 0.5)
   dt.preferences.write("enfuse_pro", "set_hdr3_contrast_weight", "float", 0.0)
   dt.preferences.write("enfuse_pro", "set_hdr3_exposure_optimum_weight", "float", 0.5)
   dt.preferences.write("enfuse_pro", "set_hdr3_exposure_width_weight", "float",0.2)
   
   -- preset DFF 1
   dt.preferences.write("enfuse_pro", "checked_dff1_hard_masks", "bool", true) 
   dt.preferences.write("enfuse_pro", "checked_dff1_save_masks", "bool", false) 
 --  dt.preferences.write("enfuse_pro", "checked_dff1_copy_exiv", "bool", true) 
   dt.preferences.write("enfuse_pro", "selected_dff1_contrast_window_size", "integer", 5)
   dt.preferences.write("enfuse_pro", "selected_dff1_contrast_edge_scale", "integer", 1)
   dt.preferences.write("enfuse_pro", "selected_dff1_contrast_min_curvature", "integer", 1)  
   dt.preferences.write("enfuse_pro", "set_dff1_exposure_weight", "float", 0.0)
   dt.preferences.write("enfuse_pro", "set_dff1_saturation_weight", "float", 0.0)
   dt.preferences.write("enfuse_pro", "set_dff1_contrast_weight", "float", 1.0)
   dt.preferences.write("enfuse_pro", "set_dff1_exposure_optimum_weight", "float", 0.5)
   dt.preferences.write("enfuse_pro", "set_dff1_exposure_width_weight", "float",0.2)
   
   -- preset DFF 2
   dt.preferences.write("enfuse_pro", "checked_dff2_hard_masks", "bool", true) 
   dt.preferences.write("enfuse_pro", "checked_dff2_save_masks", "bool", false) 
 --  dt.preferences.write("enfuse_pro", "checked_dff2_copy_exiv", "bool", true) 
   dt.preferences.write("enfuse_pro", "selected_dff2_contrast_window_size", "integer", 5)
   dt.preferences.write("enfuse_pro", "selected_dff2_contrast_edge_scale", "integer", 1)
   dt.preferences.write("enfuse_pro", "selected_dff2_contrast_min_curvature", "integer", 1)  
   dt.preferences.write("enfuse_pro", "set_dff2_exposure_weight", "float", 0.0)
   dt.preferences.write("enfuse_pro", "set_dff2_saturation_weight", "float", 0.0)
   dt.preferences.write("enfuse_pro", "set_dff2_contrast_weight", "float", 1.0)
   dt.preferences.write("enfuse_pro", "set_dff2_exposure_optimum_weight", "float", 0.5)
   dt.preferences.write("enfuse_pro", "set_dff2_exposure_width_weight", "float",0.2)
   
   -- preset DFF 3
   dt.preferences.write("enfuse_pro", "checked_dff3_hard_masks", "bool", true) 
   dt.preferences.write("enfuse_pro", "checked_dff3_save_masks", "bool", false) 
--   dt.preferences.write("enfuse_pro", "checked_dff3_copy_exiv", "bool", true) 
   dt.preferences.write("enfuse_pro", "selected_dff3_contrast_window_size", "integer", 5)
   dt.preferences.write("enfuse_pro", "selected_dff3_contrast_edge_scale", "integer", 1)
   dt.preferences.write("enfuse_pro", "selected_dff3_contrast_min_curvature", "integer", 1) 
   dt.preferences.write("enfuse_pro", "set_dff3_exposure_weight", "float", 0.0)
   dt.preferences.write("enfuse_pro", "set_dff3_saturation_weight", "float", 0.0)
   dt.preferences.write("enfuse_pro", "set_dff3_contrast_weight", "float", 1.0)
   dt.preferences.write("enfuse_pro", "set_dff3_exposure_optimum_weight", "float", 0.5)
   dt.preferences.write("enfuse_pro", "set_dff3_exposure_width_weight", "float",0.2)
   
    -- preset FREE
   dt.preferences.write("enfuse_pro", "checked_free_hard_masks", "bool", false) 
   dt.preferences.write("enfuse_pro", "checked_free_save_masks", "bool", false) 
--   dt.preferences.write("enfuse_pro", "checked_free_copy_exiv", "bool", false) 
   dt.preferences.write("enfuse_pro", "selected_free_contrast_window_size", "integer", 5)
   dt.preferences.write("enfuse_pro", "selected_free_contrast_edge_scale", "integer", 1)
   dt.preferences.write("enfuse_pro", "selected_free_contrast_min_curvature", "integer", 1)  
   dt.preferences.write("enfuse_pro", "set_free_exposure_weight", "float", 0.0)
   dt.preferences.write("enfuse_pro", "set_free_saturation_weight", "float", 0.0)
   dt.preferences.write("enfuse_pro", "set_free_contrast_weight", "float", 0.0)
   dt.preferences.write("enfuse_pro", "set_free_exposure_optimum_weight", "float", 0.0)
   dt.preferences.write("enfuse_pro", "set_free_exposure_width_weight", "float",0.0)
   
   -- output
   dt.preferences.write("enfuse_pro", "selected_output_format", "integer", 2)
      
end


--GUI
local separator1 = dt.new_widget("separator")
{
}

local separator2 = dt.new_widget("separator")
{}

local label_align_options= dt.new_widget("label")
{
     label = _('image align options:'),
     ellipsize = "start",
     halign = "start"
}

local label_enfuse_options= dt.new_widget("label")
{
     label = _('image fusion options:'),
     ellipsize = "start",
     halign = "start"
}


local label_output_format= dt.new_widget("label")
{
     label = _('target file:'),
     ellipsize = "start",
     halign = "start"
}

local label_path = dt.new_widget("label")
{
     label = _('directory'),
     ellipsize = "start",
     halign = "start"
}




check_button_image_variations = dt.new_widget("check_button")
{
    label = _('create image variants from the presets'), 
    value = dt.preferences.read("enfuse_pro", "checked_image_variants", "bool"),
    tooltip =_(''),   
    sensitive=false, --beta version doesn't support this funktion
 --[[
    clicked_callback = function(image_variations)   
      if (image_variations.value) then
             dt.preferences.write("enfuse_pro", "checked_image_variants", "bool", true)

          else
             dt.preferences.write("enfuse_pro", "checked_image_variants", "bool", false)

          end
    end,
         ]]--
    reset_callback = function(self_image_variations) 
          self_image_variations.value = dt.preferences.read("enfuse_pro", "checked_image_variants", "bool")
    end

}


check_button_radial_distortion = dt.new_widget("check_button")
{
    label = _('optimize radial distortion for all images'), 
    value = dt.preferences.read("enfuse_pro", "checked_radial_distortion", "bool"),
    tooltip =_('Optimize radial distortion for all images, except for first'),   
    clicked_callback = function(distortion)   
      if (distortion.value) then
             dt.preferences.write("enfuse_pro", "checked_radial_distortion", "bool", true)
             cmd_align_radial_distortion="-d"           
          --   return
          else
             dt.preferences.write("enfuse_pro", "checked_radial_distortion", "bool", false)
             cmd_align_radial_distortion=""
         --    return
          end
    end,
 --[[
    reset_callback = function(self_distortion) 
          self_distortion.value = dt.preferences.read("enfuse_pro", "checked_radial_distortion", "bool")
    end
    ]]--
}

check_button_optimize_field = dt.new_widget("check_button")
{
    label = _('optimize field of view for all images'), 
    value = dt.preferences.read("enfuse_pro", "checked_optimize_field", "bool"),
    tooltip =_('Optimize field of view for all images, except for first. Useful for aligning focus stacks (DFF) with slightly different magnification.'), 
    clicked_callback = function(field)   
          if (field.value) then
             dt.preferences.write("enfuse_pro", "checked_optimize_field", "bool", true)
             cmd_align_optimize_field="-m"           
          --   return
          else
             dt.preferences.write("enfuse_pro", "checked_optimize_field", "bool", false)
             cmd_align_optimize_field=""
         --    return
          end
    end,
    --[[
    reset_callback = function(self_radial) 
          self_radial.value = dt.preferences.read("enfuse_pro", "checked_optimize_field", "bool")
    end
       ]]--
}


check_button_optimize_image_center = dt.new_widget("check_button")
{
    label = _('optimize image center shift for all images'), 
    value = dt.preferences.read("enfuse_pro", "checked_optimize_image_center", "bool"),
    tooltip =_('Optimize image center shift for all images, except for first. '),   
    clicked_callback = function(center)   
         if (center.value) then
             dt.preferences.write("enfuse_pro", "checked_optimize_image_center", "bool", true)
             cmd_align_optimize_center="-i"           
          --   return
         else
             dt.preferences.write("enfuse_pro", "checked_optimize_image_center", "bool", false)
             cmd_align_optimize_center=""
         --    return
         end  
    end,
    --[[
    reset_callback = function(self_center) 
       self_center.value = dt.preferences.read("enfuse_pro", "checked_optimize_image_center", "bool")
    end
       ]]--
}


check_button_auto_crop = dt.new_widget("check_button")
{
    label = _('auto crop the image'), 
    value = dt.preferences.read("enfuse_pro", "checked_auto_crop", "bool"),
    tooltip =_(''),   
    clicked_callback = function(auto)   
         if (auto.value) then
             dt.preferences.write("enfuse_pro", "checked_auto_crop", "bool", true)
             cmd_align_auto_crop="-C"           
          --   return
         else
             dt.preferences.write("enfuse_pro", "checked_auto_crop", "bool", false)
             cmd_align_auto_crop=""
         --    return
         end  
    end,
    --[[
    reset_callback = function(self_crop) 
        self_crop.value = dt.preferences.read("enfuse_pro", "checked_auto_crop", "bool")
    end
       ]]--
}


check_button_distortion = dt.new_widget("check_button")
{
    label = _('load distortion from lens database'), 
    value = dt.preferences.read("enfuse_pro", "checked_distortion", "bool"),
    tooltip =_('try to load distortion information from lens database'),   
    clicked_callback = function(distortion)   
         if (distortion.value) then
             dt.preferences.write("enfuse_pro", "checked_distortion", "bool", true)
             cmd_align_distortion="--distortion"           
          --   return
         else
             dt.preferences.write("enfuse_pro", "checked_distortion", "bool", false)
             cmd_align_distortion=""
         --    return
         end  
    end,
    --[[
    reset_callback = function(self_distortion) 
       self_distortion.value = dt.preferences.read("enfuse_pro", "checked_distortion", "bool")
    end
       ]]--
}

--[[    
check_button_copy_exiv = dt.new_widget("check_button")
{
    label = _('copy exiv data'), 
    value = dt.preferences.read("enfuse_pro", "checked_copy_exiv", "bool"),
    tooltip =_('copy exiv data from the first image to the target image '),   
    reset_callback = function(self_copy_exif) 
       check_button_copy_exiv.value = dt.preferences.read("enfuse_pro", "checked_copy_exiv", "bool")
    end
}
]]--

check_button_hard_masks = dt.new_widget("check_button")
{
    label = _('hard mask'), 
    value = dt.preferences.read("enfuse_pro", "checked_hard_masks", "bool"),
    tooltip =_(' '),   
    reset_callback = function(self_hard_mask) 
       self_hard_mask.value = dt.preferences.read("enfuse_pro", "checked_hard_masks", "bool")
    end
    
}

check_button_save_masks = dt.new_widget("check_button")
{
    label = _('save masks'), 
    value = dt.preferences.read("enfuse_pro", "checked_save_masks", "bool"),
    tooltip =_('save the maske files for focus control '),  
    reset_callback = function(self_save_mask) 
       self_save_mask.value = dt.preferences.read("enfuse_pro", "checked_save_masks", "bool")
    end
    
}


slider_exposure_weight = dt.new_widget("slider")
{
  label = "exposure weight",
  tooltip = "",
  hard_min = 0,
  hard_max = 1,
  value = dt.preferences.read("enfuse_pro", "set_exposure_weight", "float") --1 default

}

slider_saturation_weight = dt.new_widget("slider")
{
  label = "saturation weight",
  tooltip = "",
  hard_min = 0,
  hard_max = 1,
  value = dt.preferences.read("enfuse_pro", "set_saturation_weight", "float"), --0.5
  
  
  
}

slider_contrast_weight = dt.new_widget("slider")
{
  label = "contrast weight",
  tooltip = "",
  hard_min = 0,
  hard_max = 1,
  value = dt.preferences.read("enfuse_pro", "set_contrast_weight", "float")--0 default
 
}

slider_exposure_optimum_weight = dt.new_widget("slider")
{
  label = "exposure optimum",
  tooltip = "",
  hard_min = 0,
  hard_max = 1,
  value = dt.preferences.read("enfuse_pro", "set_exposure_optimum_weight", "float")--0.5 default0

}

slider_exposure_width_weight = dt.new_widget("slider")
{
  label = "exposure width",
  tooltip = "",
  hard_min = 0,
  hard_max = 1,
  value = dt.preferences.read("enfuse_pro", "set_exposure_width_weight", "float") --0.2 default

}




file_chooser_button_path = dt.new_widget("file_chooser_button")
{
    title = _('Select export path'),  -- The title of the window when choosing a file
    is_directory = true             -- True if the file chooser button only allows directories to be selecte
}





combobox_grid_size = dt.new_widget("combobox")
{
    label = "image grid size", 
    tooltip =_('break image into a rectangular grid (gsize x gsize) and attempt to find num control points in each section'),
    value =  dt.preferences.read("enfuse_pro", "selected_grid_size", "integer"), 
    changed_callback = function(sel_grid_size) 
  --  cmd_align_grid_size="-g "..sel_grid_size.value
   --   dt.preferences.write("enfuse_pro", "selected_grid_size", "integer", sel_grid_size.selected)
    end,
    "1", "2", "3","4","5","6","7","8","9",
    
    reset_callback = function(self_grid)
       self_grid.value = dt.preferences.read("enfuse_pro", "selected_grid_size", "integer")
    end
} 


combobox_control_points = dt.new_widget("combobox")
{
    label = "control points/grid", 
    tooltip =_('Number of control points (per grid, see option -g) to create between adjacent images (default: 8).'),
    value =   dt.preferences.read("enfuse_pro", "selected_control_points", "integer"),   --8, "1", "2", "3","4","5","6","7","8","9",
    changed_callback = function(sel_control_points) 
  --  cmd_align_control_points="-c "..sel_control_points.value
    --  dt.preferences.write("enfuse_pro", "selected_control_points", "integer", sel_control_points.selected)
    end,
    "1", "2", "3","4","5","6","7","8","9",        
            
    reset_callback = function(self_points)
       self_points.value = dt.preferences.read("enfuse_pro", "selected_control_points", "integer")
    end
} 



combobox_control_points_remove = dt.new_widget("combobox")
{
    label = "remove control points with error", 
    tooltip =_('Remove all control points with an error higher than num pixels'),
    value = dt.preferences.read("enfuse_pro", "selected_control_points_remove", "integer"), --3, "1", "2", "3","4","5","6","7","8","9",
    changed_callback = function(sel_control_points_remove) 
  --  cmd_align_control_points_remove="-t "..sel_control_points_remove.value
  --    dt.preferences.write("enfuse_pro", "selected_control_points", "integer", sel_control_points_remove.selected)
    end,
    "1", "2", "3","4","5","6","7","8","9",              
    reset_callback = function(self_points_error)
       self_points_error.value = dt.preferences.read("enfuse_pro", "selected_control_points_remove", "integer")
    end
} 



combobox_correlation  = dt.new_widget("combobox")
{
    label = "correlation threshold for control points", 
    tooltip =_('Correlation threshold for identifying control points (default: 0.9).'),
    value = dt.preferences.read("enfuse_pro", "selected_correlation", "integer"), --9, "0,1", "0,2", "0,3","0,4","0,5","0,6","0,7","0,8","0,9",
    changed_callback = function(sel_correlation) 
  --  cmd_align_correlation="--corr="..sel_correlation.value
  --    dt.preferences.write("enfuse_pro", "selected_correlation", "integer", sel_correlation.selected)
    end,
    "0.1", "0.2", "0.3","0.4","0.5","0.6","0.7","0.8","0.9","1.0",  
            
            
    reset_callback = function(self_correlation)
       self_correlation.value = dt.preferences.read("enfuse_pro", "selected_correlation", "integer")
    end
} 



combobox_contrast_window_size = dt.new_widget("combobox")
{
    label = "contrast window size", 
    value = dt.preferences.read("enfuse_pro", "selected_contrast_window_size", "integer"), --3, "1", "2", "3","4","5","6","7","8","9",
    changed_callback = function(sel_window_size) 
    cmd_enfuse_contrast_window_size="--contrast-window-size="..sel_window_size.value
   --   dt.preferences.write("enfuse_pro", "selected_contrast_window_size", "integer", sel_window_size.selected)
    end,
    "1", "2", "3","4","5","6","7","8","9",         
    reset_callback = function(self)
       self.value = dt.preferences.read("enfuse_pro", "selected_contrast_window_size", "integer")
    end
} 



combobox_contrast_edge_scale = dt.new_widget("combobox")
{
    label = "contrast edge scale", 
    value = dt.preferences.read("enfuse_pro", "selected_contrast_edge_scale", "integer"), --1, "0:0:0",
    changed_callback = function(sel_contrast_edge_scale) 
    cmd_enfuse_contrast_edge_scale="--contrast-edge-scale="..sel_contrast_edge_scale.value
  --    dt.preferences.write("enfuse_pro", "selected_contrast_edge_scale", "integer", sel_contrast_edge_scale.selected)
    end,
    "0.1","0.2","0.3","0.4","0.5",
    reset_callback = function(self)
       self.value = dt.preferences.read("enfuse_pro", "selected_contrast_edge_scale", "integer")
    end
}  


combobox_contrast_min_curvature = dt.new_widget("combobox")
{
    label = "contrast min curvature", 
    value = dt.preferences.read("enfuse_pro", "selected_contrast_min_curvature", "integer"), --1, "0.0%","0.1%", "0.2%", "0.3%","0.4%","0.5%","0.6%","0.7%","0.8%","0.9%","1.0%", 
    changed_callback = function(sel_contrast_min_curvature) 
    cmd_enfuse_contrast_min_curvature="--contrast-min-curvature="..sel_contrast_min_curvature.value
  --    dt.preferences.write("enfuse_pro", "selected_contrast_min_curvature", "integer", sel_contrast_min_curvature.selected)
    end,
    "0.0%", "0.1%", "0.2%","0.3%","0.4%","0.5%","0.6%","0.7%","0.8%","0.9%","1.0%",          
    reset_callback = function(self)
       self.value = dt.preferences.read("enfuse_pro", "selected_contrast_min_curvature", "integer")
    end
}  

button_save_preset = dt.new_widget("button")
{
      label = _('save fusion preset'),
      clicked_callback = function(save_fusion_type) 
        if (combobox_fusion_type.value == "1 - high dynamic range image") then
      -- preset HDR 1
          dt.preferences.write("enfuse_pro", "checked_hdr1_hard_masks", "bool", check_button_hard_masks.value) 
          dt.preferences.write("enfuse_pro", "checked_hdr1_save_masks", "bool", check_button_save_masks.value) 
          dt.preferences.write("enfuse_pro", "checked_hdr1_copy_exiv", "bool", check_button_copy_exiv.value) 
          dt.preferences.write("enfuse_pro", "selected_hdr1_contrast_window_size", "integer", combobox_contrast_window_size.selected)
          dt.preferences.write("enfuse_pro", "selected_hdr1_contrast_edge_scale", "integer", combobox_contrast_edge_scale.selected)
          dt.preferences.write("enfuse_pro", "selected_hdr1_contrast_min_curvature", "integer", combobox_contrast_min_curvature.selected) 
          dt.preferences.write("enfuse_pro", "set_hdr1_exposure_weight", "float", slider_exposure_weight.value)
          dt.preferences.write("enfuse_pro", "set_hdr1_saturation_weight", "float", slider_saturation_weight.value)
          dt.preferences.write("enfuse_pro", "set_hdr1_contrast_weight", "float", slider_contrast_weight.value)
          dt.preferences.write("enfuse_pro", "set_hdr1_exposure_optimum_weight", "float", slider_exposure_optimum_weight.value)
          dt.preferences.write("enfuse_pro", "set_hdr1_exposure_width_weight", "float",slider_exposure_width_weight.value)
          dt.print("Preset HDR 1 saved") 
          
          elseif (combobox_fusion_type.value == "2 - high dynamic range image") then
      -- preset HDR 2
          dt.preferences.write("enfuse_pro", "checked_hdr2_hard_masks", "bool", check_button_hard_masks.value) 
          dt.preferences.write("enfuse_pro", "checked_hdr2_save_masks", "bool", check_button_save_masks.value) 
          dt.preferences.write("enfuse_pro", "checked_hdr2_copy_exiv", "bool", check_button_copy_exiv.value) 
          dt.preferences.write("enfuse_pro", "selected_hdr2_contrast_window_size", "integer", combobox_contrast_window_size.selected)
          dt.preferences.write("enfuse_pro", "selected_hdr2_contrast_edge_scale", "integer", combobox_contrast_edge_scale.selected)
          dt.preferences.write("enfuse_pro", "selected_hdr2_contrast_min_curvature", "integer", combobox_contrast_min_curvature.selected) 
          dt.preferences.write("enfuse_pro", "set_hdr2_exposure_weight", "float", slider_exposure_weight.value)
          dt.preferences.write("enfuse_pro", "set_hdr2_saturation_weight", "float", slider_saturation_weight.value)
          dt.preferences.write("enfuse_pro", "set_hdr2_contrast_weight", "float", slider_contrast_weight.value)
          dt.preferences.write("enfuse_pro", "set_hdr2_exposure_optimum_weight", "float", slider_exposure_optimum_weight.value)
          dt.preferences.write("enfuse_pro", "set_hdr2_exposure_width_weight", "float",slider_exposure_width_weight.value)
          dt.print("Preset HDR 2 saved") 
          
           
          elseif (combobox_fusion_type.value == "3 - high dynamic range image") then
      -- preset HDR 3
          dt.preferences.write("enfuse_pro", "checked_hdr3_hard_masks", "bool", check_button_hard_masks.value) 
          dt.preferences.write("enfuse_pro", "checked_hdr3_save_masks", "bool", check_button_save_masks.value) 
          dt.preferences.write("enfuse_pro", "checked_hdr3_copy_exiv", "bool", check_button_copy_exiv.value) 
          dt.preferences.write("enfuse_pro", "selected_hdr3_contrast_window_size", "integer", combobox_contrast_window_size.selected)
          dt.preferences.write("enfuse_pro", "selected_hdr3_contrast_edge_scale", "integer", combobox_contrast_edge_scale.selected)
          dt.preferences.write("enfuse_pro", "selected_hdr3_contrast_min_curvature", "integer", combobox_contrast_min_curvature.selected) 
          dt.preferences.write("enfuse_pro", "set_hdr3_exposure_weight", "float", slider_exposure_weight.value)
          dt.preferences.write("enfuse_pro", "set_hdr3_saturation_weight", "float", slider_saturation_weight.value)
          dt.preferences.write("enfuse_pro", "set_hdr3_contrast_weight", "float", slider_contrast_weight.value)
          dt.preferences.write("enfuse_pro", "set_hdr3_exposure_optimum_weight", "float", slider_exposure_optimum_weight.value)
          dt.preferences.write("enfuse_pro", "set_hdr3_exposure_width_weight", "float",slider_exposure_width_weight.value)
          dt.print("Preset HDR 3 saved") 
          
          elseif (combobox_fusion_type.value == "1 - deep focus fusion image") then
      -- preset DFF 1
          dt.preferences.write("enfuse_pro", "checked_dff1_hard_masks", "bool", check_button_hard_masks.value) 
          dt.preferences.write("enfuse_pro", "checked_dff1_save_masks", "bool", check_button_save_masks.value) 
          dt.preferences.write("enfuse_pro", "checked_dff1_copy_exiv", "bool", check_button_copy_exiv.value) 
          dt.preferences.write("enfuse_pro", "selected_dff1_contrast_window_size", "integer", combobox_contrast_window_size.selected)
          dt.preferences.write("enfuse_pro", "selected_dff1_contrast_edge_scale", "integer", combobox_contrast_edge_scale.selected)
          dt.preferences.write("enfuse_pro", "selected_dff1_contrast_min_curvature", "integer", combobox_contrast_min_curvature.selected) 
          dt.preferences.write("enfuse_pro", "set_dff1_exposure_weight", "float", slider_exposure_weight.value)
          dt.preferences.write("enfuse_pro", "set_dff1_saturation_weight", "float", slider_saturation_weight.value)
          dt.preferences.write("enfuse_pro", "set_dff1_contrast_weight", "float", slider_contrast_weight.value)
          dt.preferences.write("enfuse_pro", "set_dff1_exposure_optimum_weight", "float", slider_exposure_optimum_weight.value)
          dt.preferences.write("enfuse_pro", "set_dff2_exposure_width_weight", "float",slider_exposure_width_weight.value)
          dt.print("Preset DFF 1 saved") 
          
          elseif (combobox_fusion_type.value == "2 - deep focus fusion image") then
      -- preset DFF 2
          dt.preferences.write("enfuse_pro", "checked_dff2_hard_masks", "bool", check_button_hard_masks.value) 
          dt.preferences.write("enfuse_pro", "checked_dff2_save_masks", "bool", check_button_save_masks.value) 
          dt.preferences.write("enfuse_pro", "checked_dff2_copy_exiv", "bool", check_button_copy_exiv.value) 
          dt.preferences.write("enfuse_pro", "selected_dff2_contrast_window_size", "integer", combobox_contrast_window_size.selected)
          dt.preferences.write("enfuse_pro", "selected_dff2_contrast_edge_scale", "integer", combobox_contrast_edge_scale.selected)
          dt.preferences.write("enfuse_pro", "selected_dff2_contrast_min_curvature", "integer", combobox_contrast_min_curvature.selected) 
          dt.preferences.write("enfuse_pro", "set_dff2_exposure_weight", "float", slider_exposure_weight.value)
          dt.preferences.write("enfuse_pro", "set_dff2_saturation_weight", "float", slider_saturation_weight.value)
          dt.preferences.write("enfuse_pro", "set_dff2_contrast_weight", "float", slider_contrast_weight.value)
          dt.preferences.write("enfuse_pro", "set_dff2_exposure_optimum_weight", "float", slider_exposure_optimum_weight.value)
          dt.preferences.write("enfuse_pro", "set_dff2_exposure_width_weight", "float",slider_exposure_width_weight.value)
          dt.print("Preset DFF 2 saved") 
          
          elseif (combobox_fusion_type.value == "3 - deep focus fusion image") then
      -- preset DFF 3
          dt.preferences.write("enfuse_pro", "checked_dff3_hard_masks", "bool", check_button_hard_masks.value) 
          dt.preferences.write("enfuse_pro", "checked_dff3_save_masks", "bool", check_button_save_masks.value) 
          dt.preferences.write("enfuse_pro", "checked_dff3_copy_exiv", "bool", check_button_copy_exiv.value) 
          dt.preferences.write("enfuse_pro", "selected_dff3_contrast_window_size", "integer", combobox_contrast_window_size.selected)
          dt.preferences.write("enfuse_pro", "selected_dff3_contrast_edge_scale", "integer", combobox_contrast_edge_scale.selected)
          dt.preferences.write("enfuse_pro", "selected_dff3_contrast_min_curvature", "integer", combobox_contrast_min_curvature.selected) 
          dt.preferences.write("enfuse_pro", "set_dff3_exposure_weight", "float", slider_exposure_weight.value)
          dt.preferences.write("enfuse_pro", "set_dff3_saturation_weight", "float", slider_saturation_weight.value)
          dt.preferences.write("enfuse_pro", "set_dff3_contrast_weight", "float", slider_contrast_weight.value)
          dt.preferences.write("enfuse_pro", "set_dff3_exposure_optimum_weight", "float", slider_exposure_optimum_weight.value)
          dt.preferences.write("enfuse_pro", "set_dff3_exposure_width_weight", "float",slider_exposure_width_weight.value)
          dt.print("Preset DFF 3 saved") 
          
          elseif (combobox_fusion_type.value == "free preset") then
      -- preset FREE
          dt.preferences.write("enfuse_pro", "checked_free_hard_masks", "bool", check_button_hard_masks.value) 
          dt.preferences.write("enfuse_pro", "checked_free_save_masks", "bool", check_button_save_masks.value) 
          dt.preferences.write("enfuse_pro", "checked_free_copy_exiv", "bool", check_button_copy_exiv.value) 
          dt.preferences.write("enfuse_pro", "selected_free_contrast_window_size", "integer", combobox_contrast_window_size.selected)
          dt.preferences.write("enfuse_pro", "selected_free_contrast_edge_scale", "integer", combobox_contrast_edge_scale.selected)
          dt.preferences.write("enfuse_pro", "selected_free_contrast_min_curvature", "integer", combobox_contrast_min_curvature.selected) 
          dt.preferences.write("enfuse_pro", "set_free_exposure_weight", "float", slider_exposure_weight.value)
          dt.preferences.write("enfuse_pro", "set_free_saturation_weight", "float", slider_saturation_weight.value)
          dt.preferences.write("enfuse_pro", "set_free_contrast_weight", "float", slider_contrast_weight.value)
          dt.preferences.write("enfuse_pro", "set_free_exposure_optimum_weight", "float", slider_exposure_optimum_weight.value)
          dt.preferences.write("enfuse_pro", "set_free_exposure_width_weight", "float",slider_exposure_width_weight.value)
          dt.print("Preset free saved") 
          
        end
      end
}

button_load_preset = dt.new_widget("button")
{
      label = _('load fusion preset defaults'),
      clicked_callback = function(preset_default) 
        check_button_hard_masks.value=dt.preferences.read("enfuse_pro", "checked_hard_masks", "bool") 
        check_button_save_masks.value=dt.preferences.read("enfuse_pro", "checked_save_masks", "bool") 
        check_button_copy_exiv.value=dt.preferences.read("enfuse_pro", "checked_copy_exiv", "bool") 
        combobox_contrast_window_size.value=dt.preferences.read("enfuse_pro", "selected_contrast_window_size", "integer")
        combobox_contrast_edge_scale.value=dt.preferences.read("enfuse_pro", "selected_contrast_edge_scale", "integer")
        combobox_contrast_min_curvature.value=dt.preferences.read("enfuse_pro", "selected_contrast_min_curvature", "integer")
        slider_exposure_weight.value=dt.preferences.read("enfuse_pro", "set_exposure_weight", "float")
        slider_saturation_weight.value=dt.preferences.read("enfuse_pro", "set_saturation_weight", "float")
        slider_contrast_weight.value=dt.preferences.read("enfuse_pro", "set_contrast_weight", "float")
        slider_exposure_optimum_weight.value=dt.preferences.read("enfuse_pro", "set_exposure_optimum_weight", "float")
        slider_exposure_width_weight.value=dt.preferences.read("enfuse_pro", "set_exposure_width_weight", "float")
       end
      
}


combobox_output_format = dt.new_widget("combobox")
{
    label = "file format", 
    value = dt.preferences.read("enfuse_pro", "selected_output_format", "integer"), --2, "TIFF", "JPEG", "PNG","PNM","BMP","PBM","PGM","PPM",
    changed_callback = function(sel_output_format) 
      dt.preferences.write("enfuse_pro", "selected_output_format", "integer", sel_output_format.selected)
      if (sel_output_format.value == "TIFF") then
         cmd_suffix_output_format="tif"
      elseif (sel_output_format.value == "JPEG") then
         cmd_suffix_output_format="jpg"
      elseif (sel_output_format.value == "PNG") then
         cmd_suffix_output_format="png"
      elseif (sel_output_format.value == "PNM") then
         cmd_suffix_output_format="pnm"   
      elseif (sel_output_format.value == "BMP") then
         cmd_suffix_output_format="bmp"   
      elseif (sel_output_format.value == "PBM") then
         cmd_suffix_output_format="pbm"   
      elseif (sel_output_format.value == "PPM") then
         cmd_suffix_output_format="ppm"
      end
    end,
    "TIFF", "JPEG", "PNG","PNM","BMP","PBM","PPM",            
    reset_callback = function(self_output_format)
       self_output_format.value = dt.preferences.read("enfuse_pro", "selected_output_format", "integer")
    end
}  

-- COMBOX FUNKTIONIERT NICHT PRÜFEN!!! 

combobox_fusion_type = dt.new_widget("combobox")
{
    label = "fusion preset", 
    tooltip =_(''),
    value = dt.preferences.read("enfuse_pro", "selected_fusion_type", "integer"), --1, "high dynamic range image", "deep focus fusion image", "without preset",
    changed_callback = function(sel_fusion) 
       dt.preferences.write("enfuse_pro", "selected_fusion_type", "integer", sel_fusion.selected)
       -- preset HDR 1
       if (sel_fusion.value == "1 - high dynamic range image") then
        -- defaults for hdr images
        check_button_hard_masks.sensitive=false
        check_button_hard_masks.value=false
        slider_contrast_weight.sensitive=true
        check_button_hard_masks.value=dt.preferences.read("enfuse_pro", "checked_hdr1_hard_masks", "bool") 
        check_button_save_masks.value=dt.preferences.read("enfuse_pro", "checked_hdr1_save_masks", "bool") 
  --      check_button_copy_exiv.value=dt.preferences.read("enfuse_pro", "checked_hdr1_copy_exiv", "bool") 
        combobox_contrast_window_size.value=dt.preferences.read("enfuse_pro", "selected_hdr1_contrast_window_size", "integer")
        combobox_contrast_edge_scale.value=dt.preferences.read("enfuse_pro", "selected_hdr1_contrast_edge_scale", "integer")
        combobox_contrast_min_curvature.value=dt.preferences.read("enfuse_pro", "selected_hdr1_contrast_min_curvature", "integer") --geändert
        slider_exposure_weight.value=dt.preferences.read("enfuse_pro", "set_hdr1_exposure_weight", "float")
        slider_saturation_weight.value=dt.preferences.read("enfuse_pro", "set_hdr1_saturation_weight", "float")
        slider_contrast_weight.value=dt.preferences.read("enfuse_pro", "set_hdr1_contrast_weight", "float")
        slider_exposure_optimum_weight.value=dt.preferences.read("enfuse_pro", "set_hdr1_exposure_optimum_weight", "float")
        slider_exposure_width_weight.value=dt.preferences.read("enfuse_pro", "set_hdr1_exposure_width_weight", "float")
        
        
        -- preset HDR 2
       elseif (sel_fusion.value == "2 - high dynamic range image") then
        -- defaults for hdr images
        check_button_hard_masks.sensitive=false
        check_button_hard_masks.value=false
        slider_contrast_weight.sensitive=true
        check_button_hard_masks.value=dt.preferences.read("enfuse_pro", "checked_hdr2_hard_masks", "bool") 
        check_button_save_masks.value=dt.preferences.read("enfuse_pro", "checked_hdr2_save_masks", "bool") 
 --       check_button_copy_exiv.value=dt.preferences.read("enfuse_pro", "checked_hdr2_copy_exiv", "bool") 
        combobox_contrast_window_size.value=dt.preferences.read("enfuse_pro", "selected_hdr2_contrast_window_size", "integer")
        combobox_contrast_edge_scale.value=dt.preferences.read("enfuse_pro", "selected_hdr2_contrast_edge_scale", "integer")
        combobox_contrast_min_curvature.value=dt.preferences.read("enfuse_pro", "selected_hdr2_contrast_min_curvature", "integer") --geändert
        slider_exposure_weight.value=dt.preferences.read("enfuse_pro", "set_hdr2_exposure_weight", "float")
        slider_saturation_weight.value=dt.preferences.read("enfuse_pro", "set_hdr2_saturation_weight", "float")
        slider_contrast_weight.value=dt.preferences.read("enfuse_pro", "set_hdr2_contrast_weight", "float")
        slider_exposure_optimum_weight.value=dt.preferences.read("enfuse_pro", "set_hdr2_exposure_optimum_weight", "float")
        slider_exposure_width_weight.value=dt.preferences.read("enfuse_pro", "set_hdr2_exposure_width_weight", "float")
        
         -- preset HDR 3
       elseif (sel_fusion.value == "3 - high dynamic range image") then
        -- defaults for hdr images
        check_button_hard_masks.sensitive=false
        check_button_hard_masks.value=false
        slider_contrast_weight.sensitive=true
        check_button_hard_masks.value=dt.preferences.read("enfuse_pro", "checked_hdr3_hard_masks", "bool") 
        check_button_save_masks.value=dt.preferences.read("enfuse_pro", "checked_hdr3_save_masks", "bool") 
--        check_button_copy_exiv.value=dt.preferences.read("enfuse_pro", "checked_hdr3_copy_exiv", "bool") 
        combobox_contrast_window_size.value=dt.preferences.read("enfuse_pro", "selected_hdr3_contrast_window_size", "integer")
        combobox_contrast_edge_scale.value=dt.preferences.read("enfuse_pro", "selected_hdr3_contrast_edge_scale", "integer")
        combobox_contrast_min_curvature.value=dt.preferences.read("enfuse_pro", "selected_hdr3_contrast_min_curvature", "integer") --geändert
        slider_exposure_weight.value=dt.preferences.read("enfuse_pro", "set_hdr3_exposure_weight", "float")
        slider_saturation_weight.value=dt.preferences.read("enfuse_pro", "set_hdr3_saturation_weight", "float")
        slider_contrast_weight.value=dt.preferences.read("enfuse_pro", "set_hdr3_contrast_weight", "float")
        slider_exposure_optimum_weight.value=dt.preferences.read("enfuse_pro", "set_hdr3_exposure_optimum_weight", "float")
        slider_exposure_width_weight.value=dt.preferences.read("enfuse_pro", "set_hdr3_exposure_width_weight", "float")
        
       -- preset DFF 1
       elseif (sel_fusion.value == "1 - deep focus fusion image") then
        -- defaults for focus stacking images
        check_button_hard_masks.sensitive=false
        check_button_hard_masks.value=true
        slider_contrast_weight.sensitive=false
        check_button_hard_masks.value=dt.preferences.read("enfuse_pro", "checked_dff1_hard_masks", "bool") 
        check_button_save_masks.value=dt.preferences.read("enfuse_pro", "checked_dff1_save_masks", "bool") 
  --      check_button_copy_exiv.value=dt.preferences.read("enfuse_pro", "checked_dff1_copy_exiv", "bool") 
        combobox_contrast_window_size.value=dt.preferences.read("enfuse_pro", "selected_dff1_contrast_window_size", "integer")
        combobox_contrast_edge_scale.value=dt.preferences.read("enfuse_pro", "selected_dff1_contrast_edge_scale", "integer")
        combobox_contrast_min_curvature.value=dt.preferences.read("enfuse_pro", "selected_dff1_contrast_min_curvature", "integer")  --geändert0
        slider_exposure_weight.value=dt.preferences.read("enfuse_pro", "set_dff1_exposure_weight", "float")
        slider_saturation_weight.value=dt.preferences.read("enfuse_pro", "set_dff1_saturation_weight", "float")
        slider_contrast_weight.value=dt.preferences.read("enfuse_pro", "set_dff1_contrast_weight", "float")
        slider_exposure_optimum_weight.value=dt.preferences.read("enfuse_pro", "set_dff1_exposure_optimum_weight", "float")
        slider_exposure_width_weight.value=dt.preferences.read("enfuse_pro", "set_dff1_exposure_width_weight", "float")
        
        -- preset DFF 2
       elseif (sel_fusion.value == "2 - deep focus fusion image") then
        -- defaults for focus stacking images
        check_button_hard_masks.sensitive=false
        check_button_hard_masks.value=true
        slider_contrast_weight.sensitive=false
        check_button_hard_masks.value=dt.preferences.read("enfuse_pro", "checked_dff2_hard_masks", "bool") 
        check_button_save_masks.value=dt.preferences.read("enfuse_pro", "checked_dff2_save_masks", "bool") 
  --      check_button_copy_exiv.value=dt.preferences.read("enfuse_pro", "checked_dff2_copy_exiv", "bool") 
        combobox_contrast_window_size.value=dt.preferences.read("enfuse_pro", "selected_dff2_contrast_window_size", "integer")
        combobox_contrast_edge_scale.value=dt.preferences.read("enfuse_pro", "selected_dff2_contrast_edge_scale", "integer")
        combobox_contrast_min_curvature.value=dt.preferences.read("enfuse_pro", "selected_dff2_contrast_min_curvature", "integer")  --geändert
        slider_exposure_weight.value=dt.preferences.read("enfuse_pro", "set_dff2_exposure_weight", "float")
        slider_saturation_weight.value=dt.preferences.read("enfuse_pro", "set_dff2_saturation_weight", "float")
        slider_contrast_weight.value=dt.preferences.read("enfuse_pro", "set_dff2_contrast_weight", "float")
        slider_exposure_optimum_weight.value=dt.preferences.read("enfuse_pro", "set_dff2_exposure_optimum_weight", "float")
        slider_exposure_width_weight.value=dt.preferences.read("enfuse_pro", "set_dff2_exposure_width_weight", "float")
        
        -- preset DFF 3
       elseif (sel_fusion.value == "3 - deep focus fusion image") then
        -- defaults for focus stacking images
        check_button_hard_masks.sensitive=false
        check_button_hard_masks.value=true
        slider_contrast_weight.sensitive=false
        check_button_hard_masks.value=dt.preferences.read("enfuse_pro", "checked_dff3_hard_masks", "bool") 
        check_button_save_masks.value=dt.preferences.read("enfuse_pro", "checked_dff3_save_masks", "bool") 
  --      check_button_copy_exiv.value=dt.preferences.read("enfuse_pro", "checked_dff3_copy_exiv", "bool") 
        combobox_contrast_window_size.value=dt.preferences.read("enfuse_pro", "selected_dff3_contrast_window_size", "integer")
        combobox_contrast_edge_scale.value=dt.preferences.read("enfuse_pro", "selected_dff3_contrast_edge_scale", "integer")
        combobox_contrast_min_curvature.value=dt.preferences.read("enfuse_pro", "selected_dff3_contrast_min_curvature", "integer") --geändert
        slider_exposure_weight.value=dt.preferences.read("enfuse_pro", "set_dff3_exposure_weight", "float")
        slider_saturation_weight.value=dt.preferences.read("enfuse_pro", "set_dff3_saturation_weight", "float")
        slider_contrast_weight.value=dt.preferences.read("enfuse_pro", "set_dff3_contrast_weight", "float")
        slider_exposure_optimum_weight.value=dt.preferences.read("enfuse_pro", "set_dff3_exposure_optimum_weight", "float")
        slider_exposure_width_weight.value=dt.preferences.read("enfuse_pro", "set_dff3_exposure_width_weight", "float")
      
       -- preset FREE
       elseif (sel_fusion.value == "free preset") then
        -- enfuse defaults
        check_button_hard_masks.sensitive=true
        check_button_hard_masks.value=false
        slider_contrast_weight.sensitive=true
        check_button_hard_masks.value=dt.preferences.read("enfuse_pro", "checked_free_hard_masks", "bool") 
        check_button_save_masks.value=dt.preferences.read("enfuse_pro", "checked_free_save_masks", "bool") 
 --       check_button_copy_exiv.value=dt.preferences.read("enfuse_pro", "checked_free_copy_exiv", "bool") 
        combobox_contrast_window_size.value=dt.preferences.read("enfuse_pro", "selected_free_contrast_window_size", "integer")
        combobox_contrast_edge_scale.value=dt.preferences.read("enfuse_pro", "selected_free_contrast_edge_scale", "integer")
        combobox_contrast_min_curvature.value=dt.preferences.read("enfuse_pro", "selected_free_contrast_min_curvature", "integer") --geändert
        slider_exposure_weight.value=dt.preferences.read("enfuse_pro", "set_free_exposure_weight", "float")
        slider_saturation_weight.value=dt.preferences.read("enfuse_pro", "set_free_saturation_weight", "float")
        slider_contrast_weight.value=dt.preferences.read("enfuse_pro", "set_free_contrast_weight", "float")
        slider_exposure_optimum_weight.value=dt.preferences.read("enfuse_pro", "set_free_exposure_optimum_weight", "float")
        slider_exposure_width_weight.value=dt.preferences.read("enfuse_pro", "set_free_exposure_width_weight", "float")
        
      
       end     
    end,
    "1 - high dynamic range image", "2 - high dynamic range image","3 - high dynamic range image","1 - deep focus fusion image", "2 - deep focus fusion image","3 - deep focus fusion image","free preset",  
    
    reset_callback = function(self_type)
       combobox_fusion_type.value = dt.preferences.read("enfuse_pro", "selected_fusion_type", "integer")
    end
} 




--FUNCTION  
  
local widget = dt.new_widget("box") {
    orientation = "vertical",
    -- align
    label_align_options,
    check_button_radial_distortion,
    check_button_optimize_field,
    check_button_optimize_image_center,
    check_button_auto_crop,
    check_button_distortion,
    combobox_grid_size,
    combobox_control_points,
    combobox_control_points_remove,
    combobox_correlation,
    separator1,
    -- enfuse, exiv
    label_enfuse_options,
    combobox_fusion_type,
    check_button_image_variations,
    slider_exposure_weight,
    slider_saturation_weight,
    slider_contrast_weight,
    slider_exposure_optimum_weight,
    slider_exposure_width_weight, 
    check_button_hard_masks,
    check_button_save_masks,
 --   check_button_copy_exiv,
    combobox_contrast_edge_scale,
    combobox_contrast_min_curvature,
    combobox_contrast_window_size,
    button_save_preset,
    button_load_preset,
    -- output
    separator2,
    label_output_format,
    combobox_output_format,
    label_path,
    file_chooser_button_path,
}


local function GetFileName(full_path)
      local filename_with_suffix=full_path:match("[^/]+$" )
      return string.sub(filename_with_suffix,1, -5)
end

local function replace_comma_to_dot(s)
	return string.gsub(s, "%,", ".")
end

local function checkIfBinExists(bin)
  local handle = io.popen("which "..bin)
  local result = handle:read()
  local ret
  handle:close()
  if (result) then
 --   dt.print_error("true checkIfBinExists: "..bin)
    ret = true
  else
    dt.print_error(bin.." not found")
    ret = false
  end


  return ret
end


local function remove_temp_files()
    
                    dt.print_error("rm "..images_to_align)
                    result_to_align_images=dt.control.execute("rm "..images_to_align)
                    dt.print_error("rm "..homepath.."/.aligned_*.tif")
                    result_aligned_images=dt.control.execute("rm "..homepath.."/.aligned_*.tif")
                    
end


local function show_status(storage, image, format, filename,
  number, total, high_quality, extra_data)
     dt.print(_('export TIFF for image fusion ')..tostring(number).."/"..tostring(total))  
      
end

  



local function create_image_fusion(storage, image_table, extra_data) --finalize
-- hier kommt das Hauptprogramm hin   
   -- check installed software
   if (not (checkIfBinExists("align_image_stack"))) then
     dt.print(_('ERROR: align_image_stack not found. please install hugin.'))
     dt.print_error(_('align_image_stack not found. please install hugin.'))
     dt.control.execute( "rm ~/.local/tmp/*.tif")
     return
   elseif  (not (checkIfBinExists("enfuse"))) then
     dt.print(_('ERROR: enfuse not found. please install enfuse.'))
     dt.print_error(_('enfuse not found. please install enfuse.'))
     dt.control.execute("rm ~/.local/tmp/*.tif")
     return
   end 
   enfuseVersionStartCommand='enfuse --version | grep "enfuse 4.2"'
   enfuse_version=dt.control.execute(enfuseVersionStartCommand)
   if (enfuse_version ~= 0) then
       dt.print("ERROR: wrong enfuse version found. the plugin works only with enfuse 4.2! please install enfuse version 4.2")
       return
   end
   
 cmd_output_path = file_chooser_button_path.value
if (cmd_output_path == nil) then
     dt.print(_('ERROR: no target directory selected'))  
     return
else
   -- create align command
   dt.print("aligning images")
   
   if (check_button_radial_distortion.value) then
   cmd_align_radial_distortion="-d"
   else 
   cmd_align_radial_distortion=""
   end
   
   if (check_button_optimize_field.value) then
   cmd_align_optimize_field="-m"   
   else
   cmd_align_optimize_field=""   
   end
   
   if (check_button_optimize_image_center.value) then
   cmd_align_optimize_center="-i"  
   else
   cmd_align_optimize_center=""    
   end
   
   if (check_button_auto_crop.value) then
   cmd_align_auto_crop="-C"         
   else
   cmd_align_auto_crop=""         
   end

   if (check_button_distortionvalue) then
   cmd_align_distortion="--distortion" 
   else
   cmd_align_distortion=""
   end

   cmd_align_grid_size="-g "..combobox_grid_size.value
   cmd_align_control_points="-c "..combobox_control_points.value           
   cmd_align_control_points_remove="-t "..combobox_control_points_remove.value
   cmd_align_correlation="--corr="..combobox_correlation.value
   if (dt.preferences.read("module_enfuse_pro", "align_use_gpu", "bool")) then
   cmd_align_use_gpu="--gpu"
   else
   cmd_align_use_gpu=""   
   end
   
   images_to_align =""
   local counted_images=0
   for _,v in pairs(image_table) do
                 images_to_align = images_to_align ..v.." "
                 counted_images=counted_images+1
                 if (counted_images == 1) then
                 first_imagefile=v  
                 else
                 last_imagefile=v    
                 end
                
   end
   
    -- execute align_image_stack
   alignStartCommand="align_image_stack " ..cmd_align_radial_distortion.." "..cmd_align_optimize_field.." "..cmd_align_optimize_center.." "..cmd_align_auto_crop.." "..cmd_align_distortion.." "..cmd_align_grid_size.." "..cmd_align_control_points.." "..cmd_align_control_points_remove.." "..cmd_align_correlation.." "..cmd_align_use_gpu.." -a .aligned_ "..images_to_align
   
   dt.print_error(alignStartCommand)
   resultalign=dt.control.execute(alignStartCommand)
   if (resultalign == 0) then
    dt.print("aligning complete")
    -- enfuse
        if (check_button_image_variations.value) then
           dt.print("fuse images with presetes")
        else
            if (combobox_fusion_type.value == "1 - high dynamic range image") then
               dt.print("enfuse with value from preset HDR 1") 
            elseif (combobox_fusion_type.value == "2 - high dynamic range image") then
               dt.print("enfuse with value from preset HDR 2") 
            elseif (combobox_fusion_type.value == "3 - high dynamic range image") then
               dt.print("enfuse with value from preset HDR 3") 
            elseif (combobox_fusion_type.value == "1 - deep focus fusion image") then
               dt.print("enfuse with value from preset DFF 1") 
            elseif (combobox_fusion_type.value == "2 - deep focus fusion image") then
               dt.print("enfuse with value from preset DFF 2")
            elseif (combobox_fusion_type.value == "3 - deep focus fusion image") then
               dt.print("enfuse with value from preset DFF 3")
            elseif (combobox_fusion_type.value == "free preset") then
               dt.print("enfuse with value from free preset")
            end
       
            cmd_enfuse_exposure_weight="--exposure-weight="..(replace_comma_to_dot(slider_exposure_weight.value))
            cmd_enfuse_saturation_weight="--saturation-weight="..(replace_comma_to_dot(slider_saturation_weight.value))              
            cmd_enfuse_contrast_weight="--contrast-weight="..(replace_comma_to_dot(slider_contrast_weight.value))
            cmd_enfuse_exposure_optimum_weight="--exposure-optimum="..(replace_comma_to_dot(slider_exposure_optimum_weight.value))
            cmd_enfuse_exposure_width_weight="--exposure-width="..(replace_comma_to_dot(slider_exposure_width_weight.value))
       
            if (check_button_hard_masks.value) then
            cmd_enfuse_hard_masks="--hard-mask"
            else 
            cmd_enfuse_hard_masks=""   
            end
       
            if (check_button_save_masks.value) then
            cmd_enfuse_save_masks="--save-masks"    
            else    
            cmd_enfuse_save_masks=""
            end
       
            cmd_enfuse_contrast_window_size="--contrast-window-size="..combobox_contrast_window_size.value
            cmd_enfuse_contrast_edge_scale="--contrast-edge-scale="..combobox_contrast_edge_scale.value
            cmd_enfuse_contrast_min_curvature="--contrast-min-curvature="..combobox_contrast_min_curvature.value
            cmd_output_path=file_chooser_button_path.value
            cmd_enfuse_color_depth="--depth="..dt.preferences.read("module_enfuse_pro", "image_color_depth", "enum")
            if (combobox_output_format.value == "JPEG") then --JPEG
              cmd_enfuse_compression="--compression="..dt.preferences.read("module_enfuse_pro", "compression_jpeg", "integer")
            elseif (combobox_output_format.value == "TIFF") then --TIFF
              cmd_enfuse_compression="--compression="..dt.preferences.read("module_enfuse_pro", "compression_tiff", "enum")
            else
             cmd_enfuse_compression=""   
            end

            cmd_output_image="--output="..cmd_output_path.."/"..(GetFileName(first_imagefile)).."-"..(GetFileName(last_imagefile)).."."..cmd_suffix_output_format
            
            
            -- create enfuse command
            enfuseStartCommand="enfuse "..cmd_enfuse_exposure_weight.." "..cmd_enfuse_saturation_weight.." "..cmd_enfuse_contrast_weight.." "..cmd_enfuse_exposure_optimum_weight.." "..cmd_enfuse_exposure_width_weight.." "..cmd_enfuse_hard_masks.." "..cmd_enfuse_save_masks.." "..cmd_enfuse_contrast_window_size.." "..cmd_enfuse_contrast_edge_scale.." "..cmd_enfuse_contrast_min_curvature.." "..cmd_enfuse_color_depth.." "..cmd_enfuse_compression.." "..cmd_output_image.." "..homepath.."/.aligned_*.tif"
            dt.print_error(enfuseStartCommand)
            -- execute enfuse
            resultenfuse=dt.control.execute(enfuseStartCommand)
            if (resultenfuse == 0) then
                 --copy exiv tasgs
                 if (dt.preferences.read("module_enfuse_pro", "exivtool_copy_tags", "bool")) then
                   -- create exiv command
                   exixStartCommand="exiftool -TagsFromFile "..first_imagefile.." -exif:all --subifd:all -overwrite_original "..cmd_output_path.."/"..(GetFileName(first_imagefile)).."-"..(GetFileName(last_imagefile)).."."..cmd_suffix_output_format
                   dt.print_error(exixStartCommand)
                   -- execute exiv
                   resultexiv=dt.control.execute(exixStartCommand)
                   dt.print("process successfully completed")
                   if (resultexiv == 0) then
                       remove_temp_files()
                       dt.print("process successfully completed")
                   else
                       remove_temp_files()
                       dt.print("ERROR: exiftool doesn't work. for more informations see terminal output") 
                   end
                 end 
            else
               remove_temp_files()
               dt.print("ERROR: enfuse doesn't work. for more informations see terminal output")
            end    
             
       end
    
    
    
   else
      remove_temp_files() 
    dt.print(_("ERROR: align_image_stack doesn't work. For more information see terminal output"))
   end
   
end    
end


-- limit export to jpeg (8 bit)
local function support_format(storage, format)
  fmt = string.lower(format.name)
  if string.match(fmt,"tiff") == nil then
    return false
  else
    return true
  end   
end  



-- REGISTER
dt.register_storage("module_enfuse_pro", _('fusion to hdr or dff photo'), show_status, create_image_fusion, support_format, nil, widget)

dt.preferences.register("module_enfuse_pro",        
                        "align_use_gpu",                      -- name
                        "bool",                                    -- type
                        "enfuse pro: use GPU for remaping",        -- label
                        "set the GPU remapping for image align",   -- tooltip
                        false)                                     -- default
                        
dt.preferences.register("module_enfuse_pro",        
                        "exivtool_copy_tags",                      -- name
                        "bool",                                    -- type
                        "enfuse pro: copy exiv tags",        -- label
                        "copy the exiv tags from the first image to the target",   -- tooltip
                        true)                                     -- default                        
                        
                        
dt.preferences.register("module_enfuse_pro",        
                        "compression_jpeg",                        -- name
                        "integer",                                 -- type
                        "enfuse pro: JPEG compression",            -- label
                        "set the compression for JPEG files",      -- tooltip
                        98,                                        -- default
                        50,                                        -- min
                        100)                                       -- max
                        
dt.preferences.register("module_enfuse_pro",        
                        "compression_tiff",                        -- name
                        "enum",                                    -- type
                        "enfuse pro: TIFF compression",            -- label
                        "set the compression type for tiff files", -- tooltip
                        "LZW",                                     -- default
                        "NONE", "DEFLATE","LZW","PACKBITS")        -- values

                        
dt.preferences.register("module_enfuse_pro",        
                        "image_color_depth",                       -- name
                        "enum",                                    -- type
                        "enfuse pro: image color depth (bit)",     -- label
                        "set the output color depth",              -- tooltip
                        "16",                                      -- default
                        "8", "16","32","r32","r64")                -- values
                        